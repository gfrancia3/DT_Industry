﻿
namespace Bottling_System_Digital_Twin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.modbusTCPCom1 = new AdvancedHMIDrivers.ModbusTCPCom(this.components);
            this.momentaryButton1 = new AdvancedHMIControls.MomentaryButton();
            this.pilotLight1 = new AdvancedHMIControls.PilotLight();
            this.NormalCount = new AdvancedHMIControls.AnalogValueDisplay();
            this.DiscardCount = new AdvancedHMIControls.AnalogValueDisplay();
            this.btnPushRod = new AdvancedHMIControls.MomentaryButton();
            this.waterPump1 = new AdvancedHMIControls.WaterPump();
            this.motor1 = new AdvancedHMIControls.Motor();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pilotLight2 = new AdvancedHMIControls.PilotLight();
            this.pilotLight3 = new AdvancedHMIControls.PilotLight();
            this.label3 = new System.Windows.Forms.Label();
            this.tank1 = new AdvancedHMIControls.Tank();
            this.pipe1 = new AdvancedHMIControls.Pipe();
            this.pipe2 = new AdvancedHMIControls.Pipe();
            this.pilotLight4 = new AdvancedHMIControls.PilotLight();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnExit = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSet = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.modbusTCPCom1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // modbusTCPCom1
            // 
            this.modbusTCPCom1.DisableSubscriptions = false;
            this.modbusTCPCom1.IniFileName = "";
            this.modbusTCPCom1.IniFileSection = null;
            this.modbusTCPCom1.IPAddress = "127.0.0.1";
            this.modbusTCPCom1.MaxReadGroupSize = 20;
            this.modbusTCPCom1.PollRateOverride = 500;
            this.modbusTCPCom1.SwapBytes = true;
            this.modbusTCPCom1.SwapWords = false;
            this.modbusTCPCom1.TcpipPort = ((ushort)(502));
            this.modbusTCPCom1.TimeOut = 3000;
            this.modbusTCPCom1.UnitId = ((byte)(1));
            // 
            // momentaryButton1
            // 
            this.momentaryButton1.ButtonColor = MfgControl.AdvancedHMI.Controls.MomemtaryButton.ButtonColors.Green;
            this.momentaryButton1.ComComponent = this.modbusTCPCom1;
            this.momentaryButton1.LegendPlate = MfgControl.AdvancedHMI.Controls.MomemtaryButton.LegendPlates.Large;
            this.momentaryButton1.Location = new System.Drawing.Point(31, 376);
            this.momentaryButton1.MaximumHoldTime = 3000;
            this.momentaryButton1.MinimumHoldTime = 500;
            this.momentaryButton1.Name = "momentaryButton1";
            this.momentaryButton1.OutputType = MfgControl.AdvancedHMI.Controls.MomemtaryButton.OutputTypes.Toggle;
            this.momentaryButton1.PLCAddressClick = "00007";
            this.momentaryButton1.PLCAddressVisible = "";
            this.momentaryButton1.Size = new System.Drawing.Size(75, 110);
            this.momentaryButton1.TabIndex = 1;
            this.momentaryButton1.Text = "Main Switch";
            this.momentaryButton1.Click += new System.EventHandler(this.momentaryButton1_Click);
            // 
            // pilotLight1
            // 
            this.pilotLight1.Blink = false;
            this.pilotLight1.ComComponent = this.modbusTCPCom1;
            this.pilotLight1.LegendPlate = MfgControl.AdvancedHMI.Controls.PilotLight.LegendPlates.Large;
            this.pilotLight1.LightColor = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Green;
            this.pilotLight1.LightColorOff = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Red;
            this.pilotLight1.Location = new System.Drawing.Point(396, 258);
            this.pilotLight1.Name = "pilotLight1";
            this.pilotLight1.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.Toggle;
            this.pilotLight1.PLCAddressClick = "00002";
            this.pilotLight1.PLCAddressText = "";
            this.pilotLight1.PLCAddressValue = "00002";
            this.pilotLight1.PLCAddressVisible = "";
            this.pilotLight1.Size = new System.Drawing.Size(75, 110);
            this.pilotLight1.TabIndex = 2;
            this.pilotLight1.Text = "Filler";
            this.pilotLight1.Value = false;
            this.pilotLight1.ValueToWrite = 0;
            // 
            // NormalCount
            // 
            this.NormalCount.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.NormalCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.NormalCount.ComComponent = this.modbusTCPCom1;
            this.NormalCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NormalCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NormalCount.ForeColor = System.Drawing.Color.White;
            this.NormalCount.ForeColorInLimits = System.Drawing.Color.DarkOliveGreen;
            this.NormalCount.ForeColorOverLimit = System.Drawing.Color.Red;
            this.NormalCount.ForeColorUnderLimit = System.Drawing.Color.Yellow;
            this.NormalCount.KeypadFontColor = System.Drawing.Color.WhiteSmoke;
            this.NormalCount.KeypadMaxValue = 0D;
            this.NormalCount.KeypadMinValue = 0D;
            this.NormalCount.KeypadPasscode = null;
            this.NormalCount.KeypadScaleFactor = 1D;
            this.NormalCount.KeypadText = null;
            this.NormalCount.KeypadWidth = 300;
            this.NormalCount.Location = new System.Drawing.Point(609, 121);
            this.NormalCount.Name = "NormalCount";
            this.NormalCount.NumericFormat = null;
            this.NormalCount.PLCAddressKeypad = "";
            this.NormalCount.PLCAddressValue = ((MfgControl.AdvancedHMI.Drivers.PLCAddressItem)(resources.GetObject("NormalCount.PLCAddressValue")));
            this.NormalCount.PLCAddressValueLimitLower = null;
            this.NormalCount.PLCAddressValueLimitUpper = null;
            this.NormalCount.PLCAddressVisible = null;
            this.NormalCount.ShowValue = true;
            this.NormalCount.Size = new System.Drawing.Size(181, 64);
            this.NormalCount.TabIndex = 3;
            this.NormalCount.Text = "0000";
            this.NormalCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.NormalCount.Value = "0000";
            this.NormalCount.ValueLimitLower = -999999D;
            this.NormalCount.ValueLimitUpper = 999999D;
            this.NormalCount.ValuePrefix = null;
            this.NormalCount.ValueSuffix = null;
            this.NormalCount.VisibleControl = AdvancedHMIControls.AnalogValueDisplay.VisibleControlEnum.Always;
            // 
            // DiscardCount
            // 
            this.DiscardCount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.DiscardCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DiscardCount.ComComponent = this.modbusTCPCom1;
            this.DiscardCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DiscardCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscardCount.ForeColor = System.Drawing.Color.White;
            this.DiscardCount.ForeColorInLimits = System.Drawing.Color.Maroon;
            this.DiscardCount.ForeColorOverLimit = System.Drawing.Color.Red;
            this.DiscardCount.ForeColorUnderLimit = System.Drawing.Color.Yellow;
            this.DiscardCount.KeypadFontColor = System.Drawing.Color.Maroon;
            this.DiscardCount.KeypadMaxValue = 0D;
            this.DiscardCount.KeypadMinValue = 0D;
            this.DiscardCount.KeypadPasscode = null;
            this.DiscardCount.KeypadScaleFactor = 1D;
            this.DiscardCount.KeypadText = null;
            this.DiscardCount.KeypadWidth = 300;
            this.DiscardCount.Location = new System.Drawing.Point(609, 258);
            this.DiscardCount.Name = "DiscardCount";
            this.DiscardCount.NumericFormat = null;
            this.DiscardCount.PLCAddressKeypad = "";
            this.DiscardCount.PLCAddressValue = ((MfgControl.AdvancedHMI.Drivers.PLCAddressItem)(resources.GetObject("DiscardCount.PLCAddressValue")));
            this.DiscardCount.PLCAddressValueLimitLower = null;
            this.DiscardCount.PLCAddressValueLimitUpper = null;
            this.DiscardCount.PLCAddressVisible = null;
            this.DiscardCount.ShowValue = true;
            this.DiscardCount.Size = new System.Drawing.Size(181, 64);
            this.DiscardCount.TabIndex = 4;
            this.DiscardCount.Text = "0000";
            this.DiscardCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DiscardCount.Value = "0000";
            this.DiscardCount.ValueLimitLower = -999999D;
            this.DiscardCount.ValueLimitUpper = 999999D;
            this.DiscardCount.ValuePrefix = null;
            this.DiscardCount.ValueSuffix = null;
            this.DiscardCount.VisibleControl = AdvancedHMIControls.AnalogValueDisplay.VisibleControlEnum.Always;
            // 
            // btnPushRod
            // 
            this.btnPushRod.ButtonColor = MfgControl.AdvancedHMI.Controls.MomemtaryButton.ButtonColors.Blue;
            this.btnPushRod.ComComponent = this.modbusTCPCom1;
            this.btnPushRod.LegendPlate = MfgControl.AdvancedHMI.Controls.MomemtaryButton.LegendPlates.Large;
            this.btnPushRod.Location = new System.Drawing.Point(31, 492);
            this.btnPushRod.MaximumHoldTime = 3000;
            this.btnPushRod.MinimumHoldTime = 500;
            this.btnPushRod.Name = "btnPushRod";
            this.btnPushRod.OutputType = MfgControl.AdvancedHMI.Controls.MomemtaryButton.OutputTypes.Toggle;
            this.btnPushRod.PLCAddressClick = "00008";
            this.btnPushRod.PLCAddressVisible = "";
            this.btnPushRod.Size = new System.Drawing.Size(75, 110);
            this.btnPushRod.TabIndex = 5;
            this.btnPushRod.Text = "Push Rod";
            // 
            // waterPump1
            // 
            this.waterPump1.ComComponent = this.modbusTCPCom1;
            this.waterPump1.Location = new System.Drawing.Point(263, 310);
            this.waterPump1.Name = "waterPump1";
            this.waterPump1.PLCAddressText = "";
            this.waterPump1.PLCAddressValue = "00002";
            this.waterPump1.PLCAddressVisible = "";
            this.waterPump1.Size = new System.Drawing.Size(117, 88);
            this.waterPump1.TabIndex = 7;
            this.waterPump1.Value = false;
            // 
            // motor1
            // 
            this.motor1.ComComponent = this.modbusTCPCom1;
            this.motor1.LightColor = MfgControl.AdvancedHMI.Controls.Motor.LightColors.Green;
            this.motor1.Location = new System.Drawing.Point(203, 585);
            this.motor1.Name = "motor1";
            this.motor1.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.Toggle;
            this.motor1.PLCAddressClick = "";
            this.motor1.PLCAddressText = "";
            this.motor1.PLCAddressValue = "0001";
            this.motor1.PLCAddressVisible = "";
            this.motor1.Rotation = System.Drawing.RotateFlipType.RotateNoneFlipNone;
            this.motor1.Size = new System.Drawing.Size(75, 51);
            this.motor1.TabIndex = 8;
            this.motor1.Value = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(632, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Normal Count";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(632, 224);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 31);
            this.label2.TabIndex = 10;
            this.label2.Text = "Discard Count";
            // 
            // pilotLight2
            // 
            this.pilotLight2.Blink = false;
            this.pilotLight2.ComComponent = this.modbusTCPCom1;
            this.pilotLight2.LegendPlate = MfgControl.AdvancedHMI.Controls.PilotLight.LegendPlates.Large;
            this.pilotLight2.LightColor = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Green;
            this.pilotLight2.LightColorOff = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Red;
            this.pilotLight2.Location = new System.Drawing.Point(528, 96);
            this.pilotLight2.Name = "pilotLight2";
            this.pilotLight2.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.Toggle;
            this.pilotLight2.PLCAddressClick = "00004";
            this.pilotLight2.PLCAddressText = "";
            this.pilotLight2.PLCAddressValue = "00004";
            this.pilotLight2.PLCAddressVisible = "";
            this.pilotLight2.Size = new System.Drawing.Size(75, 110);
            this.pilotLight2.TabIndex = 11;
            this.pilotLight2.Text = "Normal";
            this.pilotLight2.Value = false;
            this.pilotLight2.ValueToWrite = 0;
            // 
            // pilotLight3
            // 
            this.pilotLight3.Blink = false;
            this.pilotLight3.ComComponent = this.modbusTCPCom1;
            this.pilotLight3.LegendPlate = MfgControl.AdvancedHMI.Controls.PilotLight.LegendPlates.Large;
            this.pilotLight3.LightColor = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Green;
            this.pilotLight3.LightColorOff = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Red;
            this.pilotLight3.Location = new System.Drawing.Point(528, 244);
            this.pilotLight3.Name = "pilotLight3";
            this.pilotLight3.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.Toggle;
            this.pilotLight3.PLCAddressClick = "00003";
            this.pilotLight3.PLCAddressText = "";
            this.pilotLight3.PLCAddressValue = "00003";
            this.pilotLight3.PLCAddressVisible = "";
            this.pilotLight3.Size = new System.Drawing.Size(75, 110);
            this.pilotLight3.TabIndex = 12;
            this.pilotLight3.Text = "Discard";
            this.pilotLight3.Value = false;
            this.pilotLight3.ValueToWrite = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(225, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(403, 46);
            this.label3.TabIndex = 13;
            this.label3.Text = "Bottle Filling System";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tank1
            // 
            this.tank1.ComComponent = this.modbusTCPCom1;
            this.tank1.HighlightColor = System.Drawing.Color.Red;
            this.tank1.HighlightKeyCharacter = "!";
            this.tank1.KeypadText = null;
            this.tank1.Location = new System.Drawing.Point(12, 60);
            this.tank1.MaxValue = 1000;
            this.tank1.MinValue = 0;
            this.tank1.Name = "tank1";
            this.tank1.NumericFormat = null;
            this.tank1.PLCAddressKeypad = "";
            this.tank1.PLCAddressText = "";
            this.tank1.PLCAddressValue = "";
            this.tank1.PLCAddressVisible = "";
            this.tank1.ScaleFactor = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.tank1.Size = new System.Drawing.Size(166, 294);
            this.tank1.TabIndex = 14;
            this.tank1.TankContentColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.tank1.Text = "Beverage";
            this.tank1.TextPrefix = null;
            this.tank1.TextSuffix = null;
            this.tank1.Value = 650F;
            this.tank1.ValueScaleFactor = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pipe1
            // 
            this.pipe1.ComComponent = this.modbusTCPCom1;
            this.pipe1.Fitting = MfgControl.AdvancedHMI.Controls.Pipe.FittingType.Straight;
            this.pipe1.HighlightColor = System.Drawing.Color.Red;
            this.pipe1.HighlightKeyCharacter = "!";
            this.pipe1.KeypadText = null;
            this.pipe1.Location = new System.Drawing.Point(154, 278);
            this.pipe1.Name = "pipe1";
            this.pipe1.NumericFormat = null;
            this.pipe1.PLCAddressKeypad = "";
            this.pipe1.PLCAddressRotate = "";
            this.pipe1.PLCAddressText = "";
            this.pipe1.PLCAddressVisible = "";
            this.pipe1.Rotation = System.Drawing.RotateFlipType.RotateNoneFlipNone;
            this.pipe1.ScaleFactor = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.pipe1.Size = new System.Drawing.Size(194, 13);
            this.pipe1.TabIndex = 15;
            this.pipe1.TextPrefix = null;
            this.pipe1.TextSuffix = null;
            // 
            // pipe2
            // 
            this.pipe2.ComComponent = this.modbusTCPCom1;
            this.pipe2.Fitting = MfgControl.AdvancedHMI.Controls.Pipe.FittingType.Elbow;
            this.pipe2.HighlightColor = System.Drawing.Color.Red;
            this.pipe2.HighlightKeyCharacter = "!";
            this.pipe2.KeypadText = null;
            this.pipe2.Location = new System.Drawing.Point(349, 272);
            this.pipe2.Name = "pipe2";
            this.pipe2.NumericFormat = null;
            this.pipe2.PLCAddressKeypad = "";
            this.pipe2.PLCAddressRotate = "";
            this.pipe2.PLCAddressText = "";
            this.pipe2.PLCAddressVisible = "";
            this.pipe2.Rotation = System.Drawing.RotateFlipType.Rotate270FlipY;
            this.pipe2.ScaleFactor = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.pipe2.Size = new System.Drawing.Size(31, 41);
            this.pipe2.TabIndex = 16;
            this.pipe2.TextPrefix = null;
            this.pipe2.TextSuffix = null;
            // 
            // pilotLight4
            // 
            this.pilotLight4.Blink = false;
            this.pilotLight4.ComComponent = this.modbusTCPCom1;
            this.pilotLight4.LegendPlate = MfgControl.AdvancedHMI.Controls.PilotLight.LegendPlates.Large;
            this.pilotLight4.LightColor = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Green;
            this.pilotLight4.LightColorOff = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Red;
            this.pilotLight4.Location = new System.Drawing.Point(154, 431);
            this.pilotLight4.Name = "pilotLight4";
            this.pilotLight4.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.Toggle;
            this.pilotLight4.PLCAddressClick = "00001";
            this.pilotLight4.PLCAddressText = "";
            this.pilotLight4.PLCAddressValue = "00001";
            this.pilotLight4.PLCAddressVisible = "";
            this.pilotLight4.Size = new System.Drawing.Size(75, 110);
            this.pilotLight4.TabIndex = 17;
            this.pilotLight4.Text = "Conveyor";
            this.pilotLight4.Value = false;
            this.pilotLight4.ValueToWrite = 0;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "conveyor-loop3.jpg");
            // 
            // btnExit
            // 
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnExit.FlatAppearance.BorderSize = 3;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnExit.Location = new System.Drawing.Point(31, 621);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(95, 44);
            this.btnExit.TabIndex = 18;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Bottling_System_Digital_Twin.Properties.Resources.conveyor501;
            this.pictureBox2.Location = new System.Drawing.Point(284, 404);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(506, 250);
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // txtIP
            // 
            this.txtIP.AcceptsReturn = true;
            this.txtIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtIP.Location = new System.Drawing.Point(184, 121);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(132, 30);
            this.txtIP.TabIndex = 21;
            this.txtIP.Text = "127.0.0.1";
            // 
            // txtPort
            // 
            this.txtPort.AcceptsReturn = true;
            this.txtPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPort.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtPort.Location = new System.Drawing.Point(184, 193);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(132, 30);
            this.txtPort.TabIndex = 22;
            this.txtPort.Text = "502";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(208, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 25);
            this.label4.TabIndex = 23;
            this.label4.Text = "IP Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(208, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 25);
            this.label5.TabIndex = 24;
            this.label5.Text = "Port Number";
            // 
            // btnSet
            // 
            this.btnSet.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSet.FlatAppearance.BorderSize = 3;
            this.btnSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSet.ForeColor = System.Drawing.Color.Green;
            this.btnSet.Location = new System.Drawing.Point(349, 146);
            this.btnSet.Name = "btnSet";
            this.btnSet.Size = new System.Drawing.Size(95, 44);
            this.btnSet.TabIndex = 25;
            this.btnSet.Text = "Set";
            this.btnSet.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(835, 677);
            this.Controls.Add(this.btnSet);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPort);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.motor1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pilotLight4);
            this.Controls.Add(this.pipe2);
            this.Controls.Add(this.pipe1);
            this.Controls.Add(this.tank1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pilotLight3);
            this.Controls.Add(this.pilotLight2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.waterPump1);
            this.Controls.Add(this.btnPushRod);
            this.Controls.Add(this.DiscardCount);
            this.Controls.Add(this.NormalCount);
            this.Controls.Add(this.pilotLight1);
            this.Controls.Add(this.momentaryButton1);
            this.Name = "Form1";
            this.Text = "Bottling System HMI";
            ((System.ComponentModel.ISupportInitialize)(this.modbusTCPCom1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private AdvancedHMIDrivers.ModbusTCPCom modbusTCPCom1;
        private AdvancedHMIControls.MomentaryButton momentaryButton1;
        private AdvancedHMIControls.PilotLight pilotLight1;
        private AdvancedHMIControls.AnalogValueDisplay NormalCount;
        private AdvancedHMIControls.AnalogValueDisplay DiscardCount;
        private AdvancedHMIControls.MomentaryButton btnPushRod;
        private AdvancedHMIControls.WaterPump waterPump1;
        private AdvancedHMIControls.Motor motor1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private AdvancedHMIControls.PilotLight pilotLight2;
        private AdvancedHMIControls.PilotLight pilotLight3;
        private System.Windows.Forms.Label label3;
        private AdvancedHMIControls.Tank tank1;
        private AdvancedHMIControls.Pipe pipe1;
        private AdvancedHMIControls.Pipe pipe2;
        private AdvancedHMIControls.PilotLight pilotLight4;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSet;
    }
}

