﻿
namespace Bottling_System_Digital_Twin
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.pilotLight4 = new AdvancedHMIControls.PilotLight();
            this.motor1 = new AdvancedHMIControls.Motor();
            this.modbusTCPCom1 = new AdvancedHMIDrivers.ModbusTCPCom(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.modbusTCPCom1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pilotLight4
            // 
            this.pilotLight4.Blink = false;
            this.pilotLight4.ComComponent = this.modbusTCPCom1;
            this.pilotLight4.LegendPlate = MfgControl.AdvancedHMI.Controls.PilotLight.LegendPlates.Large;
            this.pilotLight4.LightColor = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Green;
            this.pilotLight4.LightColorOff = MfgControl.AdvancedHMI.Controls.PilotLight.LightColors.Red;
            this.pilotLight4.Location = new System.Drawing.Point(48, 174);
            this.pilotLight4.Name = "pilotLight4";
            this.pilotLight4.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.Toggle;
            this.pilotLight4.PLCAddressClick = "00001";
            this.pilotLight4.PLCAddressText = "";
            this.pilotLight4.PLCAddressValue = "00001";
            this.pilotLight4.PLCAddressVisible = "";
            this.pilotLight4.Size = new System.Drawing.Size(75, 110);
            this.pilotLight4.TabIndex = 18;
            this.pilotLight4.Text = "Conveyor";
            this.pilotLight4.Value = false;
            this.pilotLight4.ValueToWrite = 0;
            // 
            // motor1
            // 
            this.motor1.ComComponent = this.modbusTCPCom1;
            this.motor1.LightColor = MfgControl.AdvancedHMI.Controls.Motor.LightColors.Green;
            this.motor1.Location = new System.Drawing.Point(12, 440);
            this.motor1.Name = "motor1";
            this.motor1.OutputType = MfgControl.AdvancedHMI.Controls.OutputType.Toggle;
            this.motor1.PLCAddressClick = "";
            this.motor1.PLCAddressText = "";
            this.motor1.PLCAddressValue = "00001";
            this.motor1.PLCAddressVisible = "";
            this.motor1.Rotation = System.Drawing.RotateFlipType.RotateNoneFlipNone;
            this.motor1.Size = new System.Drawing.Size(130, 88);
            this.motor1.TabIndex = 19;
            this.motor1.Value = false;
            // 
            // modbusTCPCom1
            // 
            this.modbusTCPCom1.DisableSubscriptions = false;
            this.modbusTCPCom1.IniFileName = "";
            this.modbusTCPCom1.IniFileSection = null;
            this.modbusTCPCom1.IPAddress = "127.0.0.1";
            this.modbusTCPCom1.MaxReadGroupSize = 20;
            this.modbusTCPCom1.PollRateOverride = 500;
            this.modbusTCPCom1.SwapBytes = true;
            this.modbusTCPCom1.SwapWords = false;
            this.modbusTCPCom1.TcpipPort = ((ushort)(502));
            this.modbusTCPCom1.TimeOut = 3000;
            this.modbusTCPCom1.UnitId = ((byte)(1));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(146, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1023, 592);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1273, 616);
            this.Controls.Add(this.motor1);
            this.Controls.Add(this.pilotLight4);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.modbusTCPCom1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private AdvancedHMIControls.PilotLight pilotLight4;
        private AdvancedHMIControls.Motor motor1;
        private AdvancedHMIDrivers.ModbusTCPCom modbusTCPCom1;
    }
}